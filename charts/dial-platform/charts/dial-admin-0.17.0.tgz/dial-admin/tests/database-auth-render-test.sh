#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CHART_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
HELM_BIN="${HELM_BIN:-helm}"
TEST_DIR="$(mktemp -d)"

trap 'rm -rf "${TEST_DIR}"' EXIT

fail() {
  echo "database-auth-render-test: $*" >&2
  exit 1
}

assert_count() {
  local expected="$1"
  local pattern="$2"
  local file="$3"
  local actual

  actual="$(grep -Ec -- "${pattern}" "${file}" || true)"
  [[ "${actual}" == "${expected}" ]] || fail "expected ${expected} matches for ${pattern} in ${file}, got ${actual}"
}

assert_contains() {
  local pattern="$1"
  local file="$2"

  grep -Eq -- "${pattern}" "${file}" || fail "expected ${pattern} in ${file}"
}

env_value() {
  local name="$1"
  local file="$2"

  awk -v name="${name}" '
    $0 ~ "- name: " name "$" {
      getline
      sub(/^[[:space:]]*value:[[:space:]]*/, "")
      gsub(/\"/, "")
      print
    }
  ' "${file}"
}

render() {
  local output="$1"
  shift

  "${HELM_BIN}" template database-auth-test "${CHART_DIR}" \
    --kube-version 1.25.0 \
    --set frontend.enabled=false \
    --set manager.enabled=false \
    "$@" > "${output}"
}

if ! compgen -G "${CHART_DIR}/charts/*.tgz" > /dev/null; then
  "${HELM_BIN}" dependency build "${CHART_DIR}"
fi

basic_output="${TEST_DIR}/basic.yaml"
render "${basic_output}" \
  --set postgresql.enabled=false \
  --set externalDatabase.host=postgres.example.com \
  --set externalDatabase.password=test-password
assert_count 1 '^[[:space:]]*- name: DATASOURCE_AUTH_TYPE$' "${basic_output}"
[[ "$(env_value DATASOURCE_AUTH_TYPE "${basic_output}")" == "basic" ]] || fail "basic must be the effective default authentication type"
assert_count 1 '^[[:space:]]*- name: POSTGRES_DATASOURCE_PASSWORD$' "${basic_output}"
assert_contains 'name: database-auth-test-dial-admin-externaldb$' "${basic_output}"

aws_output="${TEST_DIR}/aws.yaml"
render "${aws_output}" \
  --set postgresql.enabled=false \
  --set externalDatabase.host=my-cluster.cluster-abcdefghijkl.us-east-1.rds.amazonaws.com \
  --set externalDatabase.password=must-not-render \
  --set externalDatabase.existingSecret=unused-password-secret \
  --set backend.configuration.datasourceAuth.type=aws \
  --set backend.configuration.datasourceAuth.aws.region=us-east-1 \
  --set-string 'backend.serviceAccount.annotations.eks\.amazonaws\.com/role-arn=arn:aws:iam::123456789012:role/dial-admin-rds'
assert_count 1 '^[[:space:]]*- name: DATASOURCE_AUTH_TYPE$' "${aws_output}"
[[ "$(env_value DATASOURCE_AUTH_TYPE "${aws_output}")" == "aws" ]] || fail "AWS authentication type was not rendered"
assert_count 1 '^[[:space:]]*- name: POSTGRES_AWS_REGION$' "${aws_output}"
[[ "$(env_value POSTGRES_AWS_REGION "${aws_output}")" == "us-east-1" ]] || fail "AWS Region was not rendered"
assert_count 0 '^[[:space:]]*- name: POSTGRES_DATASOURCE_PASSWORD$' "${aws_output}"
assert_count 0 'name: database-auth-test-dial-admin-externaldb$' "${aws_output}"
assert_count 0 'unused-password-secret|bXVzdC1ub3QtcmVuZGVy' "${aws_output}"
assert_contains 'eks.amazonaws.com/role-arn: arn:aws:iam::123456789012:role/dial-admin-rds$' "${aws_output}"

aws_without_region_output="${TEST_DIR}/aws-without-region.yaml"
render "${aws_without_region_output}" \
  --set postgresql.enabled=false \
  --set externalDatabase.host=my-cluster.cluster-abcdefghijkl.us-east-1.rds.amazonaws.com \
  --set backend.configuration.datasourceAuth.type=aws
assert_count 0 '^[[:space:]]*- name: POSTGRES_AWS_REGION$' "${aws_without_region_output}"
assert_count 0 '^[[:space:]]*- name: POSTGRES_DATASOURCE_PASSWORD$' "${aws_without_region_output}"

gcp_output="${TEST_DIR}/gcp.yaml"
render "${gcp_output}" \
  --set postgresql.enabled=false \
  --set externalDatabase.host=postgres.example.com \
  --set backend.configuration.datasourceAuth.type=gcp
[[ "$(env_value DATASOURCE_AUTH_TYPE "${gcp_output}")" == "gcp" ]] || fail "GCP authentication type was not preserved"
assert_count 1 '^[[:space:]]*- name: POSTGRES_DATASOURCE_PASSWORD$' "${gcp_output}"

legacy_output="${TEST_DIR}/legacy.yaml"
render "${legacy_output}" \
  --set postgresql.enabled=false \
  --set externalDatabase.host=postgres.example.com \
  --set backend.env.DATASOURCE_AUTH_TYPE=azure
assert_count 1 '^[[:space:]]*- name: DATASOURCE_AUTH_TYPE$' "${legacy_output}"
[[ "$(env_value DATASOURCE_AUTH_TYPE "${legacy_output}")" == "azure" ]] || fail "legacy backend.env authentication type was not preserved"

precedence_output="${TEST_DIR}/precedence.yaml"
render "${precedence_output}" \
  --set postgresql.enabled=false \
  --set externalDatabase.host=my-cluster.cluster-abcdefghijkl.us-east-1.rds.amazonaws.com \
  --set backend.configuration.datasourceAuth.type=aws \
  --set backend.configuration.datasourceAuth.aws.region=us-east-1 \
  --set backend.env.DATASOURCE_AUTH_TYPE=azure \
  --set backend.env.POSTGRES_AWS_REGION=eu-west-1
assert_count 1 '^[[:space:]]*- name: DATASOURCE_AUTH_TYPE$' "${precedence_output}"
[[ "$(env_value DATASOURCE_AUTH_TYPE "${precedence_output}")" == "aws" ]] || fail "first-class authentication type must override backend.env"
assert_count 1 '^[[:space:]]*- name: POSTGRES_AWS_REGION$' "${precedence_output}"
[[ "$(env_value POSTGRES_AWS_REGION "${precedence_output}")" == "us-east-1" ]] || fail "first-class AWS Region must override backend.env"
assert_count 0 '^[[:space:]]*- name: POSTGRES_DATASOURCE_PASSWORD$' "${precedence_output}"

legacy_aws_output="${TEST_DIR}/legacy-aws.yaml"
render "${legacy_aws_output}" \
  --set postgresql.enabled=false \
  --set externalDatabase.host=my-cluster.cluster-abcdefghijkl.eu-west-1.rds.amazonaws.com \
  --set backend.env.DATASOURCE_AUTH_TYPE=aws \
  --set backend.env.POSTGRES_AWS_REGION=eu-west-1
assert_count 1 '^[[:space:]]*- name: DATASOURCE_AUTH_TYPE$' "${legacy_aws_output}"
[[ "$(env_value DATASOURCE_AUTH_TYPE "${legacy_aws_output}")" == "aws" ]] || fail "legacy AWS authentication type was not preserved"
assert_count 1 '^[[:space:]]*- name: POSTGRES_AWS_REGION$' "${legacy_aws_output}"
[[ "$(env_value POSTGRES_AWS_REGION "${legacy_aws_output}")" == "eu-west-1" ]] || fail "legacy AWS Region was not preserved"
assert_count 0 '^[[:space:]]*- name: POSTGRES_DATASOURCE_PASSWORD$' "${legacy_aws_output}"

if render "${TEST_DIR}/invalid-bundled.yaml" \
  --set backend.configuration.datasourceAuth.type=aws 2> "${TEST_DIR}/invalid-bundled.err"; then
  fail "AWS authentication with bundled PostgreSQL must fail"
fi
assert_contains 'AWS database authentication requires an external PostgreSQL database' "${TEST_DIR}/invalid-bundled.err"

if render "${TEST_DIR}/invalid-vendor.yaml" \
  --set postgresql.enabled=false \
  --set externalDatabase.host=mssql.example.com \
  --set backend.configuration.datasourceVendor=mssql \
  --set backend.configuration.datasourceAuth.type=aws 2> "${TEST_DIR}/invalid-vendor.err"; then
  fail "AWS authentication with a non-PostgreSQL datasource must fail"
fi
assert_contains 'AWS database authentication is supported only with backend.configuration.datasourceVendor=postgresql' "${TEST_DIR}/invalid-vendor.err"

echo "database-auth-render-test: all assertions passed"
